# ACB · Auditoría de la versión 4.0 · Revisión A

Esta revisión se aplica al dataset sintético v4.0.0 de motores y rodamientos. El ZIP contiene el informe, la adenda del protocolo, el código corregido y las evidencias. Los datos completos se toman de las dos partes originales. El instalador crea una carpeta nueva con todos los datos y las correcciones aplicadas.

## Uso directo del dataset corregido

Extraer ACB_v4_0_Auditada_Parte_1.zip y ACB_Motor_Rodamientos_Sintetico_v4_0_Parte_2.zip en la misma carpeta nueva. Entrar en la raíz ACB_Motor_Rodamientos_Sintetico_v4_0, ejecutar los dos controles del paso 3 y seguir docs/PROTOCOLO_AUDITADO.md. La parte 1 revisada ya lleva instaladas las correcciones.

## Montaje alternativo desde las dos partes originales en Windows / Spyder

1. Extraer ACB_Motor_Rodamientos_Sintetico_v4_0_Parte_1.zip y ACB_Motor_Rodamientos_Sintetico_v4_0_Parte_2.zip en la misma carpeta superior. La raíz del dataset debe contener SHA256.json y ml/features/R01.parquet a R16.parquet.
2. Extraer el ZIP de auditoría en otra carpeta. Con Python 3.12, desde la carpeta donde está este LEEME, ejecutar el comando siguiente. Sustituir las rutas de ejemplo. El destino debe ser una carpeta nueva fuera del original. Se copia solo el contenido verificado.

```powershell
python aplicar_revision.py "D:\ACB\ACB_Motor_Rodamientos_Sintetico_v4_0" "D:\ACB\v4_0_auditada"
```

3. En el entorno Python 3.12 destinado al proyecto, instalar las dependencias de auditoría y ejecutar los controles. El informe JSON de salida se guarda fuera de los datos congelados. En Spyder, seleccionar ese mismo intérprete.

```powershell
cd "D:\ACB\v4_0_auditada"
python -m pip install -r requirements_auditoria.txt
python src/09_verificar_integridad.py
python src/18_auditoria_preentrenamiento.py --salida "..\mi_control_preentrenamiento.json"
```

4. Leer docs/PROTOCOLO_AUDITADO.md en la copia revisada. El protocolo, sus umbrales y el criterio de éxito se fijaron antes del primer ajuste. Los siete controles históricos se pueden repetir con los comandos del README original en otra copia de trabajo, ya que vuelven a escribir informes de resultados. Para contrastar específicamente los defectos corregidos, desde el directorio de este paquete ejecutar:

```powershell
python comparar_antes_despues.py "D:\ACB\ACB_Motor_Rodamientos_Sintetico_v4_0" "D:\ACB\v4_0_auditada"
```

## Contenido y trazabilidad

- Auditoria_ACB_v4_0.pdf reúne el dictamen, los criterios, los hallazgos y la secuencia de entrenamiento para la fase siguiente.
- correcciones/docs/PROTOCOLO_AUDITADO.md contiene los pasos ejecutables, decisiones de selección, interpretación de métricas y sensibilidades.
- evidencia/ contiene la matriz de hallazgos, los controles de ambas baterías, las contrapruebas, el recuento de particiones y la comparación de la regeneración. Todas las fechas de decisión son UTC.
- huellas_correcciones.json identifica los archivos superpuestos al original. El SHA256.json de la copia creada cubre 184 archivos. El original cubre 182. Las tablas Parquet, las etiquetas y el generador mantienen sus huellas originales. Los informes históricos de v4.0.0 son el punto de partida. Los resultados de esta auditoría se encuentran en evidencia/.

La combinación verificada es Linux con Python 3.12.14. El flujo de Windows y la carga en PostgreSQL/Neon quedan sin prueba de integración en esta ejecución. La evaluación de XGBoost e Isolation Forest queda pendiente.
