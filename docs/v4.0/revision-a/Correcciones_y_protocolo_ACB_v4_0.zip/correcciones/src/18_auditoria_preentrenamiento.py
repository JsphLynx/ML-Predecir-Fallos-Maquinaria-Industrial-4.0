"""Controles adicionales sobre Parquet y regresiones. No entrena modelos."""
import argparse
import json
from pathlib import Path
import tempfile
import numpy as np
import pandas as pd
from comun import KEY, ROOT, sha
from preparacion_ml import (calendario_folds, cargar_mundo, cargar_particion, folds_temporales,
                            folds_temporales_if, inventario_mundos, matriz_predictores, unir_decisiones)
from protocolo_evaluacion import metricas_probabilidad, seleccionar_politica


def audit(root):
    tests = []
    def check(name, ok):
        if not ok:
            raise AssertionError(name)
        tests.append(name)
    def rejects(name, fn):
        try:
            fn()
        except ValueError:
            tests.append(name)
        else:
            raise AssertionError(name)
    cfg = root/'config'
    design = json.loads((cfg/'diseno_prerregistrado.json').read_text())
    check('Tres huellas de protocolo coinciden', sha(cfg/'protocolo_preentrenamiento.json') ==
          design['protocol_sha256'] == (cfg/'protocolo_sha256.txt').read_text().split()[0])
    # Casos de pérdida silenciosa, duplicación y reordenación.
    f = pd.DataFrame({'run_id':['R']*3, 'assembly_id':['A']*3, 'timestamp':range(3), 'x':[1,2,3]})
    t = f[KEY].assign(y=[0,1,0])
    rejects('Clave sin target', lambda: unir_decisiones(f, t.iloc[:-1]))
    rejects('Clave sin features', lambda: unir_decisiones(f.iloc[:-1], t))
    rejects('Clave duplicada', lambda: unir_decisiones(f, pd.concat([t, t.iloc[:1]])))
    rejects('Clave nula', lambda: unir_decisiones(f.assign(run_id=None), t))
    check('Unión independiente del orden', unir_decisiones(f, t.iloc[::-1]).y.tolist() == [0,1,0])
    probs = np.array([0,.1,.2,.3,.4,.5,.6,.7,.8,.9,1])
    metrics = metricas_probabilidad(np.arange(11)%2, probs)
    check('Once probabilidades asignadas una vez a diez intervalos',
          [b['n'] for b in metrics['calibration']] == [1]*9+[2])
    check('AP identificada explícitamente', metrics['average_precision'] == metrics['pr_auc'])
    options = pd.DataFrame(dict(partition=['validation']*2, policy_id=['nunca','otra'],
                                recall=[0.,0.], false_per_1000h=[0.,0.1]))
    check('Sin detecciones no hay política útil', seleccionar_politica(options) is None)
    keys, ref, parts, sources = [], [], [], []
    worlds = inventario_mundos(root)
    with tempfile.TemporaryDirectory() as tmp:
        small = Path(tmp)
        for name in ['data','ml/features','ml/targets','config']:
            (small/name).mkdir(parents=True, exist_ok=True)
        pd.DataFrame({'run_id':['R01']}).to_parquet(small/'data/ejecuciones.parquet')
        f.to_parquet(small/'ml/features/R01.parquet')
        rejects('Falta el archivo de un mundo', lambda: inventario_mundos(small))
        grid = pd.date_range('2024-01-01', periods=96, freq='15min', tz='UTC')
        paired = pd.DataFrame({'run_id':'R01','assembly_id':'A','timestamp':grid.delete(37)})
        paired.assign(x=0).to_parquet(small/'ml/features/R01.parquet')
        paired.assign(y24=0).to_parquet(small/'ml/targets/R01.parquet')
        (small/'config/escenario.json').write_text(json.dumps({'start':str(grid[0]),'days':1,'decision_minutes':15}))
        rejects('El mismo hueco en ambos lados de una rejilla válida', lambda: cargar_mundo(small,'R01'))
    events = pd.read_parquet(root/'data/fallos.parquet')
    plan = pd.read_parquet(root/'data/mantenimiento.parquet')
    episodes = pd.read_parquet(root/'sim_truth/episodios.parquet')
    sensors = pd.read_parquet(root/'data/sensores.parquet')
    for run in worlds:
        a = cargar_mundo(root, run)
        tr = pd.read_parquet(root/f'data/telemetria/{run}.parquet',
                             columns=KEY+['rolling_state','mechanical_power_kw','electrical_power_kw'])
        check(run+' telemetría 5 minutos', len(tr)==105120 and tr.timestamp.diff().dropna().eq(pd.Timedelta(minutes=5)).all())
        check(run+' última llegada causal', a.source_available_at_max.dropna().le(a.loc[a.source_available_at_max.notna(),'timestamp']).all())
        eligible = a.evaluation_status.eq('evaluable') & a.y24.notna()
        train = a.partition.eq('train')
        keys.append(a.loc[train & eligible, KEY])
        ref.append(a.loc[a.if_reference_observable, KEY])
        for part, g in a.groupby('partition', observed=True):
            used = eligible.loc[g.index] & (part!='excluida')
            parts.append(dict(run=run, partition=part, rows=len(g), usable=int(used.sum()),
                              positives=int(g.loc[used,'y24'].sum()), unknown=int(g.y24.isna().sum()),
                              observable=int(g.if_reference_observable.sum()),
                              ref_positive=int(g.loc[g.if_reference_observable,'y24'].eq(1).sum()),
                              ref_unknown=int(g.loc[g.if_reference_observable,'y24'].isna().sum())))
        if train.any():
            # Diagnóstico en train. Asociación de magnitudes contemporáneas, no predicción de fallo.
            truth = pd.read_parquet(root/f'sim_truth/fisica/{run}.parquet',columns=KEY+['motor_efficiency_effective'])
            d = a.loc[train & eligible, KEY+['configuration_id']].merge(tr,on=KEY,validate='one_to_one').merge(truth,on=KEY,validate='one_to_one')
            d = d[d.rolling_state.eq('laminacion') & d.mechanical_power_kw.gt(0) & d.electrical_power_kw.gt(0)].copy()
            d['ratio'] = d.mechanical_power_kw/d.electrical_power_kw
            for domain, g in d.groupby('configuration_id', observed=True):
                sources.append(dict(run=run,domain=domain,n=len(g),spearman=g.ratio.corr(g.motor_efficiency_effective,method='spearman')))
        if run==worlds[0]:
            full = matriz_predictores(a,root)
            reduced = matriz_predictores(a,root,'sin_canales_electricos')
            check('Perfiles 191 y 177 predictores; sin objetivo ni metadatos de partición',
                  len(full.columns)==191 and len(reduced.columns)==177 and not set(full)&{'partition','y24','event_id','timestamp'}
                  and not any(c.startswith(('current_a','electrical_power_kw')) for c in reduced))
    def ordered(frames):
        return pd.concat(frames).sort_values(['timestamp','run_id']).reset_index(drop=True)
    k, r = ordered(keys), ordered(ref)
    folds = []
    for i, ((it, iv), (ft, fv), (lo, hi)) in enumerate(zip(folds_temporales(k,episodes),
                folds_temporales_if(r,k,episodes), calendario_folds(k)),1):
        check(f'Fold {i}: fechas y decisiones de validación idénticas', np.array_equal(iv,fv))
        check(f'Fold {i}: referencia y entrenamiento con purga',
              max(r.iloc[ft].timestamp.max(),k.iloc[it].timestamp.max())+pd.Timedelta(hours=28)<lo)
        folds.append(dict(fold=i, train_xgb=len(it), train_if=len(ft), val_supervisada=len(iv),
                          corte_inicio=str(lo), corte_fin=str(hi)))
    counts = pd.DataFrame(parts).groupby('partition').sum(numeric_only=True)
    check('Decisiones y telemetría de 16 mundos', len(worlds)==16 and counts.rows.sum()==560640)
    check('Etiquetas disponibles en train y referencia IF observable',
          len(k)==174158 and len(r)==19861 and counts.loc['excluida','usable']==0)
    check('814 eventos y 26 sensores', len(events)==814 and len(sensors)==26)
    rejects('Test cerrado por defecto',lambda: cargar_particion('test',root))
    rejects('Estrés cerrado por defecto',lambda: cargar_particion('stress',root))
    return dict(tests=tests, passed=len(tests), splits=counts.to_dict('index'), folds=folds,
                physical_diagnostic_train=sources, telemetry=105120*len(worlds), events=len(events),
                sensors=len(sensors), preventive=int(plan.kind.eq('preventivo').sum()), models_trained=False)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root',type=Path,default=ROOT)
    parser.add_argument('--salida',type=Path)
    args=parser.parse_args()
    result=audit(args.root)
    if args.salida:
        args.salida.write_text(json.dumps(result,indent=2,ensure_ascii=False,allow_nan=False),encoding='utf-8')
    print(f"{result['passed']} controles adicionales superados")
