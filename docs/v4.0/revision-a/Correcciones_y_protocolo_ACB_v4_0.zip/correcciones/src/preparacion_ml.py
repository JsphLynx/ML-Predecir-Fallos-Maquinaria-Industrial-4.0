"""Preparación sin entrenamiento; lista permitida y cortes por fechas comunes."""
import json
from pathlib import Path
import numpy as np
import pandas as pd
from comun import ROOT, KEY

def referencia_observable(f, partition):
    return (partition.eq('train') & f.evaluation_status.eq('evaluable') &
        f.known_service_type.isin(['preventivo','correctivo']) &
        f.run_hours_since_service.between(4,24) & f.coverage_min_30m.eq(1) & f.quality_code.eq('ok'))

def inventario_mundos(root):
    """Exige los ficheros declarados, incluidos los mundos de estrés reservados."""
    root = Path(root)
    expected = pd.read_parquet(root/'data/ejecuciones.parquet', columns=['run_id']).run_id
    if expected.isna().any() or not expected.is_unique:
        raise ValueError('Catálogo de mundos inválido')
    for folder in ('ml/features', 'ml/targets'):
        present = {p.stem for p in (root/folder).glob('*.parquet')}
        if present != set(expected):
            raise ValueError(f'Inventario incompleto o inesperado en {folder}: {present ^ set(expected)}')
    return sorted(expected)


def unir_decisiones(f, t):
    """Conserva la correspondencia total, incluso si el orden de las tablas difiere."""
    if f[KEY].isna().any().any() or t[KEY].isna().any().any():
        raise ValueError('Clave nula en las decisiones')
    a = f.merge(t, on=KEY, how='outer', validate='one_to_one', indicator=True)
    if not a['_merge'].eq('both').all():
        raise ValueError('Existen claves de decisión sin correspondencia')
    return a.drop(columns='_merge')


def cargar_mundo(root, run, target_columns=None):
    root = Path(root)
    f = pd.read_parquet(root/f'ml/features/{run}.parquet')
    t = pd.read_parquet(root/f'ml/targets/{run}.parquet', columns=target_columns)
    return validar_mundo(unir_decisiones(f, t), root, run)


def validar_mundo(a, root, run):
    c = json.loads((Path(root)/'config/escenario.json').read_text(encoding='utf-8'))
    start = pd.Timestamp(c['start'])
    grid = pd.date_range(start, start + pd.Timedelta(days=c['days']),
                         freq=pd.Timedelta(minutes=c['decision_minutes']), inclusive='left')
    if (not a.run_id.eq(run).all() or a.assembly_id.nunique() != 1
            or not pd.DatetimeIndex(a.timestamp.sort_values()).equals(grid)):
        raise ValueError(f'Rejilla incompleta o mundo incorrecto: {run}')
    return a


def matriz_predictores(a, root=ROOT, perfil='completo'):
    c = json.loads((Path(root)/'ml/columnas_modelo.json').read_text(encoding='utf-8'))
    cols = c['numeric'] + c['categorical']
    if len(set(cols)) != len(cols) or set(cols).intersection(c['forbidden']):
        raise ValueError('Contrato de predictores incoherente')
    if perfil == 'sin_canales_electricos':
        cols = [v for v in cols if not any(v == s or v.startswith(s + '_')
                for s in ('current_a', 'electrical_power_kw'))]
    elif perfil != 'completo':
        raise ValueError('Perfil desconocido')
    x = a.loc[:, cols].copy()
    for col in c['categorical']:
        x[col] = x[col].astype(object).where(x[col].notna(), np.nan)
    return x


def cargar_particion(partition='train',root=ROOT,reference=None,final_evaluation=False,perfil='completo'):
    root = Path(root)
    if partition not in ('train', 'validation', 'test', 'stress'):
        raise ValueError('Partición no permitida')
    if partition in ('test', 'stress') and not final_evaluation:
        raise ValueError('Congelar protocolo antes de abrir evaluación final')
    if reference is not None and (partition != 'train' or reference not in ('observable', 'ideal')):
        raise ValueError('Referencia solo train: observable o ideal')
    catalog = pd.read_parquet(root/'data/ejecuciones.parquet').set_index('run_id')
    frames = []
    for run in inventario_mundos(root):
        if catalog.loc[run, 'scenario'].startswith('stress') != (partition == 'stress'):
            continue
        a = cargar_mundo(root, run)
        mask = a.partition.eq(partition) & a.evaluation_status.eq('evaluable')
        if reference is None:
            mask &= a.y24.notna()
        else:
            column = 'if_reference_observable' if reference == 'observable' else 'healthy_reference_if'
            mask &= a[column]
        frames.append(a.loc[mask])
    a = pd.concat(frames).sort_values(['timestamp', 'run_id']).reset_index(drop=True)
    return matriz_predictores(a, root, perfil), a.y24.copy(), a[KEY].copy()

def preprocesador(root=ROOT,columns=None):
    from sklearn.compose import ColumnTransformer
    from sklearn.impute import SimpleImputer
    from sklearn.preprocessing import OneHotEncoder,StandardScaler
    from sklearn.pipeline import Pipeline
    c=json.loads((Path(root)/'ml/columnas_modelo.json').read_text())
    num=[v for v in c['numeric'] if columns is None or v in columns]
    cat=[v for v in c['categorical'] if columns is None or v in columns]
    return ColumnTransformer([
        ('numeric',Pipeline([('imputer',SimpleImputer(strategy='median',add_indicator=True,keep_empty_features=True)),('scale',StandardScaler())]),num),
        ('category',Pipeline([('imputer',SimpleImputer(strategy='constant',fill_value='sin_receta')),('encode',OneHotEncoder(handle_unknown='ignore',sparse_output=False))]),cat)])

def calendario_folds(keys_supervisadas, folds=3):
    t = keys_supervisadas.timestamp
    lo, hi = t.min(), t.max()
    if folds < 1 or not lo < hi:
        raise ValueError('Calendario temporal vacío')
    for i in range(folds):
        yield (lo + (hi-lo) * (.4+i*.6/folds), lo + (hi-lo) * (.4+(i+1)*.6/folds))


def _mascaras_fold(keys, episodes, start, end, purge_hours):
    t = keys.timestamp
    train = t + pd.Timedelta(hours=purge_hours) < start
    valid = (t >= start) & (t + pd.Timedelta(hours=purge_hours) < end)
    for boundary in (start, end):
        crossing = episodes[episodes.start.lt(boundary) & episodes.end.gt(boundary)]
        for ep in crossing.itertuples():
            blocked = keys.run_id.eq(ep.run_id) & t.ge(ep.start-pd.Timedelta(hours=24)) & t.lt(ep.end)
            train &= ~blocked
            valid &= ~blocked
    return np.flatnonzero(train), np.flatnonzero(valid)


def folds_temporales(keys, episodes, folds=3, purge_hours=28):
    for start, end in calendario_folds(keys, folds):
        yield _mascaras_fold(keys, episodes, start, end, purge_hours)


def folds_temporales_if(keys_reference, keys_supervisadas, episodes, folds=3, purge_hours=28):
    """Índices train sobre la referencia IF; índices valid sobre las claves supervisadas."""
    for start, end in calendario_folds(keys_supervisadas, folds):
        train, _ = _mascaras_fold(keys_reference, episodes, start, end, purge_hours)
        _, valid = _mascaras_fold(keys_supervisadas, episodes, start, end, purge_hours)
        yield train, valid

HISTORIAL_CARGA=['run_hours_since_service','starts_last_24h','load_ratio','motor_speed_rpm','rolling_state','known_service_type']
CONDICION=['bearing_temperature_de_c','bearing_temperature_nde_c','winding_temperature_c','vibration_de_mm_s','vibration_nde_mm_s']

class ReglaCondicion:
    """Score máximo de condición relativo a percentiles de train; no probabilidad."""
    def fit(self,x,y=None):
        self.median_=x[CONDICION].median();self.scale_=(x[CONDICION].quantile(.95)-self.median_).clip(lower=1e-6);return self
    def score(self,x):return ((x[CONDICION]-self.median_)/self.scale_).max(axis=1)

def comparadores_sin_ajustar(root=ROOT):
    from sklearn.dummy import DummyClassifier
    from sklearn.linear_model import LogisticRegression
    from sklearn.pipeline import Pipeline
    return {'constante':DummyClassifier(strategy='prior'), 'condicion':ReglaCondicion(),
        'historial_carga':Pipeline([('preprocesador',preprocesador(root,HISTORIAL_CARGA)),('modelo',LogisticRegression(max_iter=1000,random_state=20261105))])}
