"""Crea una copia auditada desde los dos ZIP v4.0 previamente extraídos juntos."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import tempfile

BASE = 'af5bff63d3ddc42a772c5bd5994480149ef4f7457ba0437b04b882fca8bcc1a8'


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def aplicar(origen, destino):
    here = Path(__file__).resolve().parent
    origen, destino = origen.resolve(), destino.resolve()
    if destino.exists() or origen in destino.parents:
        raise ValueError('El destino debe ser nuevo y estar fuera del original.')
    manifest = origen/'SHA256.json'
    if sha(manifest) != BASE:
        raise ValueError('La huella del manifiesto no corresponde a la entrega auditada.')
    files = json.loads(manifest.read_text(encoding='utf-8'))
    fixes = json.loads((here/'huellas_correcciones.json').read_text(encoding='utf-8'))
    destino.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(dir=destino.parent) as staging:
        work = Path(staging)/'dataset'
        for items, folder in ((files, origen), (fixes, here/'correcciones')):
            for name, expected in items.items():
                target = work/name
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(folder/name, target)
                if sha(target) != expected:
                    raise ValueError(f'Archivo ausente o distinto de la versión auditada: {name}')
        (work/'SHA256.json').write_text(json.dumps(files | fixes, indent=2), encoding='utf-8')
        if destino.exists():
            raise FileExistsError(destino)
        work.rename(destino)
    print(f'Copia verificada creada en {destino}')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('origen', type=Path)
    parser.add_argument('destino', type=Path)
    args = parser.parse_args()
    aplicar(args.origen, args.destino)
