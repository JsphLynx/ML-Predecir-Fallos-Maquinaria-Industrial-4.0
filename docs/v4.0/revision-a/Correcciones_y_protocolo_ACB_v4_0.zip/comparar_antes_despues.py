"""Contrapruebas con casos fabricados sobre ambos módulos de la entrega."""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import numpy as np
import pandas as pd


def mod(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def resultados(root):
    sys.path.insert(0, str(root/'src'))
    try:
        prep = mod(root/'src/preparacion_ml.py','preparacion_local')
        ev = mod(root/'src/protocolo_evaluacion.py','evaluacion_local')
        p = np.array([0,.1,.2,.3,.4,.5,.6,.7,.8,.9,1.])
        cal = ev.metricas_probabilidad(np.arange(11)%2,p)
        opciones = pd.DataFrame(dict(partition=['validation'], policy_id=['nunca'],recall=[0.],false_per_1000h=[0.]))
        # Ejercita el cargador mediante archivos, usando un catálogo válido con un target ausente.
        from tempfile import TemporaryDirectory
        with TemporaryDirectory() as tmp:
            tmp=Path(tmp)
            for folder in ('config','data','ml/features','ml/targets'):
                (tmp/folder).mkdir(parents=True)
            (tmp/'config/escenario.json').write_text(json.dumps(dict(start='2024-01-01T00:00:00Z',days=1,decision_minutes=15)))
            (tmp/'ml/columnas_modelo.json').write_text(json.dumps(dict(numeric=['x'],categorical=[],forbidden=[])))
            pd.DataFrame({'run_id':['R01'],'scenario':['base']}).to_parquet(tmp/'data/ejecuciones.parquet')
            f=pd.DataFrame(dict(run_id='R01',assembly_id='A',timestamp=pd.date_range('2024-01-01',periods=96,freq='15min',tz='UTC'),evaluation_status='evaluable',x=1))
            f.to_parquet(tmp/'ml/features/R01.parquet')
            f.iloc[:-1][prep.KEY].assign(y24=0,partition='train').to_parquet(tmp/'ml/targets/R01.parquet')
            try:
                rows=len(prep.cargar_particion(root=tmp)[0])
            except ValueError as error:
                rows=str(error)
        digest=(root/'config/protocolo_sha256.txt').read_text().split()[0]
        measures=dict(huella_auxiliar=digest,
                      registros_calibracion=sum(x['n'] for x in cal['calibration']),
                      decision_sin_politica_util=ev.seleccionar_politica(opciones) is None,
                      carga_con_un_target_ausente=rows)
        measures['huella_real']=hashlib.sha256((root/'config/protocolo_preentrenamiento.json').read_bytes()).hexdigest()
        return measures
    finally:
        sys.path.pop(0)


if __name__ == '__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('original',type=Path)
    parser.add_argument('revisada',type=Path)
    parser.add_argument('--salida',type=Path)
    args=parser.parse_args()
    values={k:resultados(path) for k,path in [('original',args.original),('revisada',args.revisada)]}
    assert values['original']['carga_con_un_target_ausente']==95 and isinstance(values['revisada']['carga_con_un_target_ausente'],str)
    assert values['original']['registros_calibracion']==10 and values['revisada']['registros_calibracion']==11
    assert not values['original']['decision_sin_politica_util'] and values['revisada']['decision_sin_politica_util']
    for key,v in values.items():
        assert (v['huella_auxiliar']==v['huella_real'])==(key=='revisada')
    out=json.dumps(values,indent=2,ensure_ascii=False)
    if args.salida: args.salida.write_text(out,encoding='utf-8')
    print(out)
